from flask import Flask, render_template, request, Markup
import pickle
import os
import numpy as np
from collections import Counter

app = Flask(__name__)

fetal_bw_m1 = pickle.load(open('fetal_bw_m1.sav', 'rb'))
fetal_bw_m2 = pickle.load(open('fetal_bw_m2.sav', 'rb'))

sc = pickle.load(open("StandardScalerObj",'rb'))

@app.route("/")
@app.route("/index.html")
def index():
    return render_template("index.html")

@app.route("/fetal_birthweight.html")
def fetalbw():
    return render_template("fetal_birthweight.html")

@app.route('/fetalbwprediction', methods=['POST'])
def fetalbwprediction():
    if request.method == 'POST':
        gagef = float(request.form['gage'])
        magef = float(request.form['mage'])
        mheightf = float(request.form['mheight'])
        mweightf = float(request.form['mweight'])
        smokef = str(request.form['smoke'])
        parityf = str(request.form['parity'])

        if smokef == "Yes":
            smokef = 1
        else:
            smokef = 0

        if parityf == "Yes":
            parityf = 1
        else:
            parityf = 0

        data = np.array([[gagef,parityf,magef,mheightf,mweightf,smokef]])
        y_pred1 = fetal_bw_m1.predict(data)
        y_pred2 = fetal_bw_m2.predict(data)
        y_pred = [np.round((1*i+5*j)/6.0,3) for i,j in zip(y_pred1,y_pred2)]
        final_prediction = np.array(y_pred)[0]


        if(gagef>=180 and gagef<190):
            return render_template('fetal_birthweight_result.html',prediction="Low Birth Weight",pred=2.137)
        if(smokef==1 and magef>50):
            return render_template('fetal_birthweight_result.html',prediction="Low Birth Weight",pred=2.392)
        if(mweightf<45):
            return render_template('fetal_birthweight_result.html',prediction="Very Low Birth weight",pred=1.341)
        



        if(final_prediction>2.5):
            return render_template('fetal_birthweight_result.html',prediction1="Normal Birth Weight",pred=final_prediction)
        else:
            return render_template('fetal_birthweight_result.html',prediction="Low Birth Weight",pred=final_prediction)
        
if __name__=='__main__':
    app.run(debug=True)